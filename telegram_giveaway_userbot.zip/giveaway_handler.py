# giveaway logic
