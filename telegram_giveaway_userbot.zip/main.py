# main bot logic
