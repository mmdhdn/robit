# playwright logic to enter miniapp
